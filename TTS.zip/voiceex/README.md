# STT TTS 메모장 어플 구현입니다    ( 배포 X 공부용 )
 제작 :  김건 이창희
 
 ## source
 + MAIN = app%main%java%com.example.voiceex%MainActivity
 + Layout -> app%main%res%layout%activity_main.xml
 + manifest -> main%AndroidManifest.xml
 
 ## 언어 자바&코틀린
 
